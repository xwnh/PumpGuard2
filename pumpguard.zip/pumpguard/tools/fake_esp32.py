"""
مُحاكي ESP32 — لاختبار مسار MQTT الكامل بدون عتاد.

يرسل قراءات بمقياس نموذج مصغّر (مختلف تماماً عن المضخات الصناعية) لإثبات أن الخادم
يعايره على حالته السليمة ثم يكشف العطل. ويستجيب لأمر الإيقاف مثل الجهاز الحقيقي.

    python tools/fake_esp32.py --host 127.0.0.1 --pump A2 --fault-after 60 --mode bearing

ملاحظة أمانة: هذا مُحاكٍ وليس حساسات حقيقية — لا تعرضه على اللجنة على أنه عتاد.
"""
import argparse
import json
import random
import time

import paho.mqtt.client as mqtt

ap = argparse.ArgumentParser()
ap.add_argument("--host", default="127.0.0.1")
ap.add_argument("--port", type=int, default=1883)
ap.add_argument("--station", default="A")
ap.add_argument("--pump", default="A2")
ap.add_argument("--mode", default="bearing", choices=["bearing", "cavitation", "overheat", "clog"])
ap.add_argument("--fault-after", type=float, default=0, help="ثوانٍ قبل بدء العطل (0 = لا عطل)")
ap.add_argument("--fault-duration", type=float, default=240, help="مدة تدهور العطل بالثواني")
ap.add_argument("--rate", type=float, default=1.0, help="ثواني بين القراءات")
a = ap.parse_args()

state = {"running": True}
rng = random.Random()


def on_message(c, u, msg):
    cmd = json.loads(msg.payload).get("action")
    if cmd == "stop":
        state["running"] = False
    elif cmd == "start":
        state["running"] = True
    print(f"[أمر من الخادم] {cmd}")


c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"fake-{a.pump}")
c.on_message = on_message
c.connect(a.host, a.port, 30)
c.subscribe(f"pumpguard/{a.station}/{a.pump}/command", 1)
c.loop_start()

t0 = time.time()
print(f"يبث {a.pump} إلى {a.host}:{a.port} — اضغط Ctrl+C للإيقاف")
while True:
    el = time.time() - t0
    k = 0.0
    if a.fault_after and el > a.fault_after:
        k = min(1.0, (el - a.fault_after) / a.fault_duration)
    vib, temp, cur, pr, fl = 0.05, 26.0, 0.9, 0.35, 6.0
    if a.mode == "bearing":
        vib *= 1 + 3.5 * k ** 1.5; temp += 6 * k; cur *= 1 + 0.08 * k
    elif a.mode == "cavitation":
        pr *= 1 - 0.38 * k; vib *= 1 + 2.2 * k; fl *= 1 - 0.3 * k
    elif a.mode == "overheat":
        temp += 11 * k; cur *= 1 + 0.22 * k
    elif a.mode == "clog":
        fl *= 1 - 0.5 * k; cur *= 1 + 0.15 * k; pr *= 1 + 0.2 * k
    msg = {
        "temp": temp + rng.gauss(0, 0.1), "vib": vib * (1 + rng.gauss(0, 0.05)),
        "current": cur + rng.gauss(0, 0.01), "pressure": pr + rng.gauss(0, 0.005), "flow": fl + rng.gauss(0, 0.1),
    }
    if state["running"]:
        c.publish(f"pumpguard/{a.station}/{a.pump}/telemetry", json.dumps(msg))
        print(f"{el:6.0f}s k={k:.2f} {json.dumps({x: round(y, 2) for x, y in msg.items()})}")
    time.sleep(a.rate)
