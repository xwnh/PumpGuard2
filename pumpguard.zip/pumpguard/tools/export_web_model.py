"""
يدرّب نسخة مضغوطة من النماذج ويصدّرها JSON لتعمل داخل المتصفح (نسخة الجوال).

    python -m tools.export_web_model
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor

from ml.features import window_features
from ml.train import CLASSES, build_dataset, evaluate_policy
from simulator.pump_sim import SENSORS

OUT = Path(__file__).resolve().parent.parent / "dashboard" / "web_model.json"


def export_trees(model):
    """يُرجع قائمة (لكل تكرار) من قائمة (لكل صنف) من الأشجار [f,t,l,r,v]."""
    out = []
    for it in model._predictors:
        group = []
        for tp in it:
            n = tp.nodes
            group.append({
                "f": [-1 if bool(x) else int(f) for x, f in zip(n["is_leaf"], n["feature_idx"])],
                "t": [float(x) for x in n["num_threshold"]],
                "l": [int(x) for x in n["left"]],
                "r": [int(x) for x in n["right"]],
                "v": [float(f"{x:.8g}") for x in n["value"]],
            })
        out.append(group)
    return out


def eval_tree(tr, x):
    i = 0
    while tr["f"][i] != -1:
        i = tr["l"][i] if x[tr["f"][i]] <= tr["t"][i] else tr["r"][i]
    return tr["v"][i]


def raw(export, baseline, x, k):
    return float(baseline[k]) + sum(eval_tree(g[k], x) for g in export)


def main():
    print("بيانات التدريب ...")
    X, yf, yr, ym = build_dataset(range(0, 320), range(10_000, 10_070), stride=3)
    fail = HistGradientBoostingClassifier(max_iter=70, max_leaf_nodes=15, learning_rate=0.12, random_state=0).fit(X, yf)
    rul = HistGradientBoostingRegressor(max_iter=80, max_leaf_nodes=15, learning_rate=0.12, random_state=0).fit(X, yr)
    mode = HistGradientBoostingClassifier(max_iter=40, max_leaf_nodes=12, learning_rate=0.15, random_state=0).fit(X, ym)

    ef, er, em = export_trees(fail), export_trees(rul), export_trees(mode)
    bf = np.asarray(fail._baseline_prediction).ravel().tolist()
    br = np.asarray(rul._baseline_prediction).ravel().tolist()
    bm = np.asarray(mode._baseline_prediction).ravel().tolist()

    # تحقق: حساب الأشجار المصدّرة = نتائج sklearn
    rng = np.random.default_rng(0)
    idx = rng.choice(len(X), 300, replace=False)
    err_f = err_r = 0.0
    ok_m = 0
    for i in idx:
        x = X[i]
        pf = 1 / (1 + np.exp(-raw(ef, bf, x, 0)))
        err_f = max(err_f, abs(pf - fail.predict_proba(x[None])[0, 1]))
        err_r = max(err_r, abs(raw(er, br, x, 0) - rul.predict(x[None])[0]))
        logits = np.array([raw(em, bm, x, k) for k in range(len(CLASSES))])
        ok_m += int(np.argmax(logits) == mode.predict(x[None])[0])
    print(f"أقصى فرق احتمال العطل: {err_f:.2e} | العمر المتبقي: {err_r:.2e} | تطابق النوع: {ok_m}/300")
    assert err_f < 1e-4 and err_r < 2e-3 and ok_m >= 298, "التصدير لا يطابق sklearn"

    print("تقييم السياسة بالنموذج المضغوط ...")
    pol = evaluate_policy((fail, rul, mode), n_fail=40, n_healthy=25)
    print(json.dumps(pol, ensure_ascii=False))

    payload = {
        "classes": CLASSES, "sensors": SENSORS,
        "fail": {"baseline": bf, "trees": ef}, "rul": {"baseline": br, "trees": er},
        "mode": {"baseline": bm, "trees": em}, "policy_eval": pol,
    }
    OUT.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
    print(f"حجم الملف: {OUT.stat().st_size / 1024:.0f} KB")


if __name__ == "__main__":
    main()
