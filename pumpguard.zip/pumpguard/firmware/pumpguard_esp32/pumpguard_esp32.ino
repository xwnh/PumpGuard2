/*
 * PumpGuard — ESP32 firmware
 * ---------------------------------------------------------------
 * يقرأ 5 حساسات من مضخة حقيقية (نموذج مصغّر) ويرسلها كل ثانية عبر MQTT،
 * ويستقبل أوامر الإيقاف/التشغيل من الخادم ويحرّك الريلاي.
 * وفيه حماية محلية مستقلة (Edge Fail-safe): تعمل حتى لو انقطع الإنترنت أو الخادم.
 *
 * المكتبات (Library Manager):
 *   PubSubClient (Nick O'Leary) | OneWire | DallasTemperature | Adafruit INA219
 *
 * اللوحة: ESP32 Dev Module
 *
 * تحذير سلامة: هذا الكود مخصص لمضخة تيار مستمر صغيرة (12V). لا توصل جهد الكهرباء العام
 * (220V) مباشرة بالريلاي دون مقاول كهرباء مؤهل وحماية مناسبة.
 */
#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Adafruit_INA219.h>

// ============================== الإعدادات ==============================
const char* WIFI_SSID  = "YOUR_WIFI";
const char* WIFI_PASS  = "YOUR_PASSWORD";
const char* MQTT_HOST  = "192.168.1.10";   // عنوان الحاسوب الذي يشغّل الخادم وMosquitto
const int   MQTT_PORT  = 1883;
const char* STATION_ID = "A";
const char* PUMP_ID    = "A2";             // يجب أن يطابق MQTT_PUMPS في الخادم

// الأطراف
#define PIN_ONEWIRE 4     // DS18B20 (مع مقاومة 4.7k إلى 3.3V)
#define PIN_FLOW    27    // YF-S201 (إشارة النبضات)
#define PIN_PRESS   35    // حساس ضغط 0.5-4.5V عبر مقسّم جهد (10k علوية / 20k سفلية)
#define PIN_RELAY   26    // ريلاي (فعّال عند LOW — أغلب الوحدات)
#define PIN_LED_G   25
#define PIN_LED_R   33
// I2C: SDA=21, SCL=22  →  MPU6050 (0x68) + INA219 (0x40)

// معايرة
const float PRESS_RANGE_BAR   = 12.0;   // المدى الكامل للحساس (0-1.2MPa = 12 بار)
const float FLOW_PULSES_PER_L = 450.0;  // YF-S201: ≈ 7.5 Hz لكل لتر/دقيقة
const float VIB_SCALE         = 1000.0; // مؤشر اهتزاز نسبي (g × 1000)؛ الخادم يعايره على الحالة السليمة

// حماية محلية مستقلة عن الخادم
const float LOCAL_TEMP_LIMIT    = 80.0; // °م
const float LOCAL_CURRENT_LIMIT = 2.8;  // أمبير (اضبطه حسب مضختك)
// =======================================================================

WiFiClient wifi;
PubSubClient mqtt(wifi);
OneWire oneWire(PIN_ONEWIRE);
DallasTemperature ds(&oneWire);
Adafruit_INA219 ina;

volatile uint32_t pulses = 0;
void IRAM_ATTR onPulse() { pulses++; }

bool pumpOn = true;
bool localLatched = false;   // أوقفت الحماية المحلية المضخة
float lastTemp = 25.0;
char topicTele[64], topicCmd[64], topicAlert[64];

void relay(bool on) {
  pumpOn = on;
  digitalWrite(PIN_RELAY, on ? LOW : HIGH);
  digitalWrite(PIN_LED_G, on ? HIGH : LOW);
  digitalWrite(PIN_LED_R, on ? LOW : HIGH);
}

void onMessage(char* topic, byte* payload, unsigned int len) {
  char buf[96];
  len = min(len, (unsigned int)(sizeof(buf) - 1));
  memcpy(buf, payload, len);
  buf[len] = 0;
  if (strstr(buf, "stop")) {
    relay(false);
    Serial.println("[CMD] stop");
  } else if (strstr(buf, "start")) {
    localLatched = false;
    relay(true);
    Serial.println("[CMD] start");
  }
}

void mpuInit() {
  Wire.beginTransmission(0x68); Wire.write(0x6B); Wire.write(0); Wire.endTransmission(true);  // إيقاظ
  Wire.beginTransmission(0x68); Wire.write(0x1C); Wire.write(0x08); Wire.endTransmission(true); // ±4g
}

// تسارع RMS (بعد حذف مركّبة الجاذبية) خلال ~200ms
float measureVibration() {
  const int N = 120;
  static float mag[N];
  float sum = 0;
  for (int i = 0; i < N; i++) {
    Wire.beginTransmission(0x68); Wire.write(0x3B); Wire.endTransmission(false);
    Wire.requestFrom(0x68, 6, true);
    int16_t ax = (Wire.read() << 8) | Wire.read();
    int16_t ay = (Wire.read() << 8) | Wire.read();
    int16_t az = (Wire.read() << 8) | Wire.read();
    float gx = ax / 8192.0, gy = ay / 8192.0, gz = az / 8192.0;   // ±4g
    mag[i] = sqrtf(gx * gx + gy * gy + gz * gz);
    sum += mag[i];
    delayMicroseconds(1200);
  }
  float mean = sum / N, var = 0;
  for (int i = 0; i < N; i++) var += (mag[i] - mean) * (mag[i] - mean);
  return sqrtf(var / N);
}

void ensureWifi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.print("WiFi...");
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) { delay(300); Serial.print("."); }
  Serial.println(WiFi.status() == WL_CONNECTED ? " OK" : " فشل");
}

void ensureMqtt() {
  if (mqtt.connected() || WiFi.status() != WL_CONNECTED) return;
  String cid = String("pumpguard-") + PUMP_ID;
  if (mqtt.connect(cid.c_str())) {
    mqtt.subscribe(topicCmd, 1);
    Serial.println("MQTT متصل");
  }
}

void localProtection(float temp, float current) {
  if (pumpOn && (temp > LOCAL_TEMP_LIMIT || current > LOCAL_CURRENT_LIMIT)) {
    relay(false);
    localLatched = true;
    Serial.println("[LOCAL] إيقاف حماية محلية");
    if (mqtt.connected())
      mqtt.publish(topicAlert, "{\"event\":\"local_protection_stop\"}");
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_RELAY, OUTPUT); pinMode(PIN_LED_G, OUTPUT); pinMode(PIN_LED_R, OUTPUT);
  relay(true);
  Wire.begin(21, 22); Wire.setClock(400000);
  mpuInit();
  if (!ina.begin()) Serial.println("تحذير: INA219 غير موجود");
  ds.begin(); ds.setResolution(10); ds.setWaitForConversion(false); ds.requestTemperatures();
  pinMode(PIN_FLOW, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(PIN_FLOW), onPulse, FALLING);
  analogSetPinAttenuation(PIN_PRESS, ADC_11db);
  snprintf(topicTele, sizeof(topicTele), "pumpguard/%s/%s/telemetry", STATION_ID, PUMP_ID);
  snprintf(topicCmd, sizeof(topicCmd), "pumpguard/%s/%s/command", STATION_ID, PUMP_ID);
  snprintf(topicAlert, sizeof(topicAlert), "pumpguard/%s/%s/alert", STATION_ID, PUMP_ID);
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(onMessage);
}

void loop() {
  ensureWifi();
  ensureMqtt();
  mqtt.loop();

  static uint32_t last = 0;
  if (millis() - last < 1000) return;
  uint32_t dtms = millis() - last; last = millis();

  // الحرارة (قراءة التحويل السابق ثم طلب جديد)
  float t = ds.getTempCByIndex(0);
  if (t > -50 && t < 125) lastTemp = t;
  ds.requestTemperatures();

  float vib = measureVibration() * VIB_SCALE;
  float current = fabsf(ina.getCurrent_mA()) / 1000.0;

  float vpin = analogReadMilliVolts(PIN_PRESS) / 1000.0;
  float vsens = vpin * 1.5;                                    // تعويض المقسّم 10k/20k
  float press = (vsens - 0.5) / 4.0 * PRESS_RANGE_BAR;
  if (press < 0) press = 0;

  noInterrupts(); uint32_t p = pulses; pulses = 0; interrupts();
  float litres = p / FLOW_PULSES_PER_L;
  float flow_m3h = litres * (3600000.0 / dtms) / 1000.0;      // م³/ساعة

  localProtection(lastTemp, current);

  char msg[160];
  snprintf(msg, sizeof(msg),
           "{\"temp\":%.2f,\"vib\":%.3f,\"current\":%.3f,\"pressure\":%.3f,\"flow\":%.3f}",
           lastTemp, vib, current, press, flow_m3h);
  if (mqtt.connected() && pumpOn) mqtt.publish(topicTele, msg);
  Serial.println(msg);
}
