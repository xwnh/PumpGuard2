#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
pip install -q -r requirements.txt
[ -f models/fail_clf.joblib ] || python -m ml.train
echo "===== افتح المتصفح على:  http://localhost:8000 ====="
python -m uvicorn server.app:app --host 0.0.0.0 --port 8000
