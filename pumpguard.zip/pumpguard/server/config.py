"""إعدادات PumpGuard — كل ما يمكن تعديله في مكان واحد."""
import os

# سرعة المحاكاة: كل خطوة = دقيقة من زمن المحطة. 0.4 ثانية حقيقية لكل دقيقة محاكاة.
TICK_SECONDS = float(os.getenv("TICK_SECONDS", "0.4"))

# محطات الضخ (آخر مضخة في كل محطة = احتياطية)
STATIONS = [
    {"id": "A", "name": "محطة الضخ A — شمال الرياض", "demand": 600, "pumps": ["A1", "A2", "A3"]},
    {"id": "B", "name": "محطة الضخ B — شرق الرياض", "demand": 600, "pumps": ["B1", "B2", "B3"]},
]

# أعطال تلقائية عشوائية (للتشغيل الطويل). الافتراضي: مغلقة، والعطل يُحقن بزر من اللوحة
NATURAL_FAULTS = os.getenv("NATURAL_FAULTS", "0") == "1"

# إعدادات زمنية (بالخطوات)
RAMP_TICKS = 5          # زمن وصول المضخة الاحتياطية للتدفق الكامل
REPAIR_TICKS = 150      # مدة الصيانة قبل عودة المضخة كاحتياطية
FAILOVER_DELAY = 10     # تأخر استجابة المشغّل عند العطل المفاجئ (بدون النظام)
FAIL_DISPLAY = 25       # مدة بقاء حالة "عطل" ظاهرة قبل الانتقال للصيانة

# ---------------------------------------------------------------------------
# افتراضات اقتصادية — قابلة للتعديل. ليست بيانات حقيقية، يجب استبدالها بأرقام
# الجهة المشغّلة (هيئة المياه / شركة المياه الوطنية) عند التطبيق الفعلي.
# ---------------------------------------------------------------------------
UNPLANNED_FAILURE_COST_SAR = float(os.getenv("UNPLANNED_COST", "85000"))  # إصلاح طارئ + فاقد مياه + غرامات
PLANNED_STOP_COST_SAR = float(os.getenv("PLANNED_COST", "12000"))         # صيانة مجدولة
UNPLANNED_DOWNTIME_HOURS = 36.0
PLANNED_DOWNTIME_HOURS = 6.0

# ---------------------------------------------------------------------------
# الربط الحقيقي عبر MQTT (اختياري)
#   MQTT_HOST=192.168.1.10  MQTT_PUMPS=A2   ← المضخة A2 تأخذ بياناتها من ESP32
# ---------------------------------------------------------------------------
MQTT_HOST = os.getenv("MQTT_HOST", "")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_USER = os.getenv("MQTT_USER", "")
MQTT_PASS = os.getenv("MQTT_PASS", "")
MQTT_PUMPS = [p.strip() for p in os.getenv("MQTT_PUMPS", "").split(",") if p.strip()]
MQTT_TEMP_GAIN = float(os.getenv("MQTT_TEMP_GAIN", "3.0"))  # تضخيم تغيّر الحرارة لنموذج مصغّر

# ---------------------------------------------------------------------------
# قنوات التنبيه (اختيارية) — بدونها تُسجَّل الإشعارات كمحاكاة داخل اللوحة
# ---------------------------------------------------------------------------
TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
SMTP_HOST = os.getenv("SMTP_HOST", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASS = os.getenv("SMTP_PASS", "")
MAIL_TO = os.getenv("MAIL_TO", "")

# تقرير دوري تلقائي كل N دقيقة حقيقية (0 = معطّل)
REPORT_INTERVAL_MIN = float(os.getenv("REPORT_INTERVAL_MIN", "0"))

# ملخصات بالذكاء الاصطناعي عبر Claude (اختياري): ضع ANTHROPIC_API_KEY
LLM_MODEL = os.getenv("PUMPGUARD_LLM_MODEL", "claude-sonnet-5-5")
