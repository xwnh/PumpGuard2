"""قنوات التنبيه: Telegram وبريد إلكتروني (اختياريان). بدون إعداد تُسجَّل كمحاكاة."""
from __future__ import annotations

import json
import smtplib
import threading
import urllib.request
import uuid
from email.message import EmailMessage
from typing import List, Optional

from server import config as C


def channels_status() -> dict:
    return {
        "telegram": bool(C.TELEGRAM_TOKEN and C.TELEGRAM_CHAT_ID),
        "email": bool(C.SMTP_HOST and C.MAIL_TO),
    }


def _telegram_text(text: str):
    url = f"https://api.telegram.org/bot{C.TELEGRAM_TOKEN}/sendMessage"
    body = json.dumps({"chat_id": C.TELEGRAM_CHAT_ID, "text": text}).encode()
    req = urllib.request.Request(url, body, {"Content-Type": "application/json"})
    urllib.request.urlopen(req, timeout=10).read()


def _telegram_doc(pdf: bytes, filename: str, caption: str):
    boundary = uuid.uuid4().hex
    parts = []

    def field(name, value):
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())

    field("chat_id", C.TELEGRAM_CHAT_ID)
    field("caption", caption)
    parts.append(
        (f'--{boundary}\r\nContent-Disposition: form-data; name="document"; filename="{filename}"\r\n'
         f"Content-Type: application/pdf\r\n\r\n").encode() + pdf + b"\r\n"
    )
    parts.append(f"--{boundary}--\r\n".encode())
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{C.TELEGRAM_TOKEN}/sendDocument", b"".join(parts),
        {"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    urllib.request.urlopen(req, timeout=30).read()


def _email(subject: str, body: str, pdf: Optional[bytes], filename: str):
    msg = EmailMessage()
    msg["Subject"], msg["From"], msg["To"] = subject, C.SMTP_USER or "pumpguard@localhost", C.MAIL_TO
    msg.set_content(body)
    if pdf:
        msg.add_attachment(pdf, maintype="application", subtype="pdf", filename=filename)
    with smtplib.SMTP(C.SMTP_HOST, C.SMTP_PORT, timeout=20) as s:
        s.starttls()
        if C.SMTP_USER:
            s.login(C.SMTP_USER, C.SMTP_PASS)
        s.send_message(msg)


def send(text: str, kind: str = "info", pdf: Optional[bytes] = None, filename: str = "report.pdf") -> List[str]:
    """يرسل في خيوط خلفية حتى لا يعطّل المحرك. يُرجع أسماء القنوات المستخدمة."""
    st = channels_status()
    used = []

    def run(fn, *a):
        def _w():
            try:
                fn(*a)
            except Exception as e:  # noqa: BLE001
                print(f"[notify] فشل الإرسال: {e}")
        threading.Thread(target=_w, daemon=True).start()

    if st["telegram"]:
        used.append("Telegram")
        run(_telegram_doc, pdf, filename, text) if pdf else run(_telegram_text, text)
    if st["email"]:
        used.append("Email")
        run(_email, text.split("\n")[0][:120], text, pdf, filename)
    return used or ["محاكاة"]
