"""
محرك PumpGuard: يربط المضخات (محاكاة أو ESP32 حقيقي) بالنماذج وسياسة القرار
ويتخذ إجراءات الإيقاف والتحويل للمضخة الاحتياطية ويحسب الأثر المالي.
"""
from __future__ import annotations

import datetime as dt
import json
import random
import time
from collections import deque
from pathlib import Path
from typing import Callable, Optional

import joblib
import numpy as np

from ml.features import WINDOW, window_features
from server import config as C
from server.decision import HARD_LIMITS, Decider, hard_limit_hit
from simulator.pump_sim import BASE, LABELS_AR, MODE_AR, MODES, SENSORS, UNITS, Pump

ROOT = Path(__file__).resolve().parent.parent
MODELS_DIR = ROOT / "models"
DATA_DIR = ROOT / "data"
CLASSES = ["none"] + MODES
HIST = 90
Z_SCALE = {"temp": 5.0, "vib": 0.8, "current": 3.0, "pressure": 0.3, "flow": 20.0}
LEVEL_AR = {"normal": "طبيعي", "watch": "مراقبة", "warning": "تحذير", "critical": "حرج"}
STATE_AR = {
    "running": "تشغيل", "standby": "احتياطي", "stopped": "متوقفة",
    "failed": "عطل", "maintenance": "صيانة",
}


def _r(x, n=1):
    return None if x is None else round(float(x), n)


class PumpUnit:
    def __init__(self, pid: str, station_id: str, standby: bool, source: str, rng: random.Random):
        self.id = pid
        self.station_id = station_id
        self.source = source  # sim | mqtt
        self.rng = rng
        if source == "sim":
            self.sim: Optional[Pump] = Pump(pid, rng=rng, healthy=not C.NATURAL_FAULTS,
                                            state="standby" if standby else "running")
        else:
            self.sim = None
        self.mqtt_state = "running"
        self.window: deque = deque(maxlen=WINDOW)
        self.hist = {s: deque(maxlen=HIST) for s in SENSORS}
        self.p_hist: deque = deque(maxlen=HIST)
        self.decider = Decider()
        self.reading = {s: 0.0 for s in SENSORS}
        self.eff_flow = 0.0
        self.p_fail = 0.0
        self.rul = 400.0
        self.health = 100.0
        self.level = "normal"
        self.mode_probs: deque = deque(maxlen=5)
        self.likely_mode = "none"
        self.mode_conf = 0.0
        self.ramp = 0
        self.repair_left = 0
        self.failed_ticks = 0
        self.failure_logged = False
        self.critical_notified = False
        self.explain = ""
        # معايرة المصدر الحقيقي
        self.raw_buf: deque = deque(maxlen=30)
        self.raw_base: Optional[dict] = None
        self.last_raw_ts = 0.0

    @property
    def state(self) -> str:
        return self.sim.state if self.sim else self.mqtt_state

    @state.setter
    def state(self, v: str):
        if self.sim:
            self.sim.state = v
        else:
            self.mqtt_state = v

    def clear_monitoring(self):
        self.window.clear()
        self.decider.reset()
        self.p_fail, self.rul, self.health, self.level = 0.0, 400.0, 100.0, "normal"
        self.mode_probs.clear()
        self.likely_mode, self.mode_conf = "none", 0.0
        self.critical_notified = False
        self.explain = ""


class Station:
    def __init__(self, cfg: dict, rng: random.Random):
        self.id, self.name, self.demand = cfg["id"], cfg["name"], cfg["demand"]
        self.units = []
        n = len(cfg["pumps"])
        for i, pid in enumerate(cfg["pumps"]):
            src = "mqtt" if (C.MQTT_HOST and pid in C.MQTT_PUMPS) else "sim"
            self.units.append(PumpUnit(pid, self.id, standby=(i == n - 1), source=src, rng=rng))
        self.flow = 0.0
        self.service = 100.0
        # وحدة كشف التسرب
        self.leak_true = 0.0
        self.leak_target = 0.0
        self.down_flow = 0.0
        self.down_pressure = 3.9
        self.imb_ema = 0.0
        self.leak_count = 0
        self.leak_clear = 0
        self.leak_alarm = False
        self.leak_loss = 0.0


class Engine:
    def __init__(self, seed: int = 7):
        self.rng = random.Random(seed)
        self.stations = [Station(c, self.rng) for c in C.STATIONS]
        self.units = {u.id: u for s in self.stations for u in s.units}
        self.station_of = {u.id: s for s in self.stations for u in s.units}
        self.t = 0
        self.auto_shutdown = True
        self.tick_seconds = C.TICK_SECONDS
        self.events: deque = deque(maxlen=300)
        self._eid = 0
        self.kpi = {
            "avoided_failures": 0, "unplanned_failures": 0, "false_alarms": 0, "shutdowns": 0,
            "avoided_cost": 0.0, "failure_cost": 0.0, "hours_saved": 0.0, "leaks_detected": 0,
        }
        self.lead_times: list = []
        self.notifier: Optional[Callable[[str, str, Optional[str]], list]] = None
        self.command_hook: Optional[Callable[[str, str, str], None]] = None  # (station, pump, action)
        self.mqtt_latest: dict = {}
        self.channels_log: deque = deque(maxlen=50)
        self.fail_clf = joblib.load(MODELS_DIR / "fail_clf.joblib")
        self.rul_reg = joblib.load(MODELS_DIR / "rul_reg.joblib")
        self.mode_clf = joblib.load(MODELS_DIR / "mode_clf.joblib")
        mp = MODELS_DIR / "metrics.json"
        self.metrics = json.loads(mp.read_text(encoding="utf-8")) if mp.exists() else {}
        DATA_DIR.mkdir(exist_ok=True)
        self._audit = DATA_DIR / "events.jsonl"
        self._audit.write_text("", encoding="utf-8")
        # تهيئة: تعبئة نافذة المضخات العاملة
        for u in self.units.values():
            if u.sim and u.state == "running":
                for _ in range(WINDOW + 2):
                    self._ingest(u, u.sim.step())
        self._event("info", None, "تم تشغيل النظام — جميع المضخات تحت المراقبة")

    # ------------------------------------------------------------------ أحداث
    def _event(self, kind: str, u: Optional[PumpUnit], msg: str, data: Optional[dict] = None, notify=False,
               station: Optional[str] = None):
        self._eid += 1
        ev = {
            "id": self._eid, "kind": kind, "t": self.t,
            "ts": dt.datetime.now().strftime("%H:%M:%S"),
            "pump": u.id if u else None,
            "station": u.station_id if u else station,
            "message": msg, "data": data or {}, "sent": [],
        }
        if notify and self.notifier:
            icon = {"warning": "⚠️", "shutdown": "🛑", "failure": "🔴", "failover": "🔁", "leak": "💧",
                    "repair": "✅"}.get(kind, "ℹ️")
            ev["sent"] = self.notifier(f"{icon} PumpGuard — {msg}", kind, None)
        self.events.appendleft(ev)
        with self._audit.open("a", encoding="utf-8") as f:
            f.write(json.dumps({k: v for k, v in ev.items() if k != "data"}, ensure_ascii=False) + "\n")
        return ev

    # ------------------------------------------------------------------ مصدر حقيقي
    def mqtt_ingest(self, pump_id: str, vals: dict):
        u = self.units.get(pump_id)
        if not u or u.source != "mqtt":
            return
        try:
            raw = {s: float(vals[s]) for s in SENSORS}
        except (KeyError, TypeError, ValueError):
            return
        self.mqtt_latest[pump_id] = raw
        u.last_raw_ts = time.time()

    def calibrate(self, pump_id: str) -> bool:
        u = self.units.get(pump_id)
        if not u or u.source != "mqtt" or len(u.raw_buf) < 10:
            return False
        u.raw_base = {s: float(np.mean([r[s] for r in u.raw_buf])) for s in SENSORS}
        u.clear_monitoring()
        self._event("info", u, f"تمت معايرة {u.id} على الحالة السليمة الحالية")
        return True

    def _normalize(self, u: PumpUnit, raw: dict) -> Optional[dict]:
        u.raw_buf.append(raw)
        if u.raw_base is None:
            if len(u.raw_buf) >= 30:
                self.calibrate(u.id)
            return None
        b = u.raw_base
        out = {}
        for s in SENSORS:
            if s == "temp":
                out[s] = BASE[s] + (raw[s] - b[s]) * C.MQTT_TEMP_GAIN
            else:
                out[s] = BASE[s] * (raw[s] / b[s]) if b[s] > 1e-6 else BASE[s]
        return out

    # ------------------------------------------------------------------ خطوة
    def _ingest(self, u: PumpUnit, raw: dict):
        u.reading = raw
        running = u.state in ("running", "failed")
        u.ramp = u.ramp + 1 if running else 0
        u.eff_flow = raw["flow"] * min(1.0, u.ramp / C.RAMP_TICKS) if running else 0.0
        for s in SENSORS:
            u.hist[s].append(round(raw[s], 2))
        if u.state == "running":
            u.window.append([raw[s] for s in SENSORS])

    def tick(self):
        self.t += 1
        ready = []
        for st in self.stations:
            for u in st.units:
                raw = None
                if u.sim:
                    raw = u.sim.step()
                elif u.state in ("running", "failed"):
                    r = self.mqtt_latest.get(u.id)
                    if r is not None and time.time() - u.last_raw_ts < 5:
                        raw = self._normalize(u, r)
                    self.mqtt_latest.pop(u.id, None)
                else:
                    raw = {"temp": 30.0, "vib": 0.15, "current": 0.3, "pressure": 0.1, "flow": 0.0}
                if raw is not None:
                    self._ingest(u, raw)
                self._lifecycle(u, st)
                # لا نقيّم إلا عند وصول قراءة جديدة (حتى لا تتكرر العينة نفسها في عدّاد التأكيد)
                if raw is not None and u.state == "running" and len(u.window) >= WINDOW:
                    ready.append(u)
        if ready:
            F = np.array([window_features(np.array(u.window)) for u in ready])
            p = self.fail_clf.predict_proba(F)[:, 1]
            rul = np.expm1(self.rul_reg.predict(F))
            mp = self.mode_clf.predict_proba(F)
            for u, pp, rr, mm in zip(ready, p, rul, mp):
                self._assess(u, float(pp), float(max(rr, 0.0)), mm)
        for st in self.stations:
            self._station_metrics(st)

    # ------------------------------------------------------------------ دورة حياة المضخة
    def _lifecycle(self, u: PumpUnit, st: Station):
        if u.state == "failed":
            if not u.failure_logged:
                u.failure_logged = True
                u.failed_ticks = 0
                self.kpi["unplanned_failures"] += 1
                self.kpi["failure_cost"] += C.UNPLANNED_FAILURE_COST_SAR
                self._event(
                    "failure", u,
                    f"عطل مفاجئ في {u.id} ({st.name}) — توقف تدفق المياه. "
                    f"التكلفة التقديرية {C.UNPLANNED_FAILURE_COST_SAR:,.0f} ريال",
                    {"trace": self._trace(u)}, notify=True,
                )
            u.failed_ticks += 1
            if u.failed_ticks == C.FAILOVER_DELAY:
                self._start_standby(st, u, auto=False)
            if u.failed_ticks >= C.FAIL_DISPLAY:
                u.state = "maintenance"
                u.repair_left = C.REPAIR_TICKS
                u.clear_monitoring()
        elif u.state == "maintenance":
            u.repair_left -= 1
            if u.repair_left <= 0:
                self._repair(u)

    def _repair(self, u: PumpUnit):
        if u.sim:
            u.sim.reset(healthy=not C.NATURAL_FAULTS, state="standby")
        else:
            u.state = "standby"
        u.clear_monitoring()
        u.failure_logged = False
        u.ramp = 0
        self._event("repair", u, f"اكتملت صيانة {u.id} — عادت للخدمة كمضخة احتياطية")

    def _start_standby(self, st: Station, replacing: PumpUnit, auto=True) -> Optional[PumpUnit]:
        for c in st.units:
            if c is not replacing and c.state == "standby":
                c.state = "running"
                c.clear_monitoring()
                c.ramp = 0
                if c.sim:
                    c.sim.temp = 40.0
                if self.command_hook:
                    self.command_hook(st.id, c.id, "start")
                self._event(
                    "failover", c,
                    f"تشغيل المضخة الاحتياطية {c.id} تلقائياً بدل {replacing.id} — استمرار الخدمة",
                    notify=True,
                )
                return c
        return None

    # ------------------------------------------------------------------ التقييم والقرار
    def _assess(self, u: PumpUnit, p: float, rul: float, mp: np.ndarray):
        st = self.station_of[u.id]
        u.p_fail, u.rul = p, rul
        u.p_hist.append(round(p, 3))
        u.mode_probs.append(mp)
        avg = np.mean(u.mode_probs, axis=0)
        idx = 1 + int(np.argmax(avg[1:]))
        u.likely_mode = CLASSES[idx] if p >= 0.2 else "none"
        u.mode_conf = float(avg[idx]) / max(float(avg[1:].sum()), 1e-9)
        h = 100.0 * min(max(rul / 300.0, 0.0), 1.0)
        u.health = 0.7 * u.health + 0.3 * h
        prev = u.level
        level, reason = u.decider.update(p, rul, u.reading)
        u.level = level
        u.explain = self._explain(u)

        if level in ("warning", "critical") and prev in ("normal", "watch") and level == "warning":
            self._event(
                "warning", u,
                f"تحذير: {u.id} — احتمال عطل {p:.0%}، العمر المتبقي المقدّر ≈ {rul:.0f} دقيقة. {u.explain}",
                {"p_fail": p, "rul": rul, "trace": self._trace(u)}, notify=True,
            )
        if level == "critical":
            self._on_critical(u, st, p, rul, reason)

    def _on_critical(self, u: PumpUnit, st: Station, p: float, rul: float, reason: Optional[str]):
        if not self.auto_shutdown:
            if not u.critical_notified:
                u.critical_notified = True
                self._event("critical", u,
                            f"حالة حرجة في {u.id} — الإيقاف التلقائي معطّل، يلزم تدخل المشغّل فوراً. {u.explain}",
                            {"trace": self._trace(u)}, notify=True)
            return
        has_standby = any(c is not u and c.state == "standby" for c in st.units)
        if not has_standby and reason != "hard_limit" and rul > 20:
            if not u.critical_notified:
                u.critical_notified = True
                self._event("critical", u,
                            f"حالة حرجة في {u.id} ولا توجد مضخة احتياطية — يلزم قرار المشغّل (سيتوقف تلقائياً إذا "
                            f"انخفض العمر المتبقي عن 20 دقيقة). {u.explain}",
                            {"trace": self._trace(u)}, notify=True)
            return
        self.stop_pump(u.id, auto=True, reason=reason, p=p, rul=rul)

    def stop_pump(self, pid: str, auto=False, reason: Optional[str] = None, p: float = 0.0, rul: float = 0.0):
        u = self.units.get(pid)
        if not u or u.state != "running":
            return False
        st = self.station_of[pid]
        true_rul, damage = None, None
        if u.sim:
            true_rul, damage = u.sim.true_rul(), u.sim.damage
        trace = self._trace(u)
        mode_txt = MODE_AR.get(u.likely_mode, "غير محدد")
        if auto:
            why = "تجاوز حد أمان صلب" if reason == "hard_limit" else "تنبؤ الذكاء الاصطناعي بعطل وشيك"
            msg = (f"إيقاف تلقائي لـ {u.id} قبل العطل — السبب: {why}. النوع المرجّح: {mode_txt}. "
                   f"{u.explain}")
        else:
            msg = f"إيقاف يدوي لـ {u.id} بقرار المشغّل"
        self.kpi["shutdowns"] += 1
        u.state = "maintenance"
        u.repair_left = C.REPAIR_TICKS
        if self.command_hook:
            self.command_hook(st.id, u.id, "stop")
        # أثر مالي
        avoided = None
        if auto:
            if true_rul is not None:
                avoided = damage is not None and damage > 0.15 and true_rul < 10_000
            else:
                avoided = rul <= 90
            if avoided:
                self.kpi["avoided_failures"] += 1
                net = C.UNPLANNED_FAILURE_COST_SAR - C.PLANNED_STOP_COST_SAR
                self.kpi["avoided_cost"] += net
                self.kpi["hours_saved"] += C.UNPLANNED_DOWNTIME_HOURS - C.PLANNED_DOWNTIME_HOURS
                if true_rul is not None:
                    self.lead_times.append(true_rul)
                msg += (f" — توفير متوقع {net:,.0f} ريال"
                        + (f"، كان العطل سيقع بعد ≈ {true_rul:.0f} دقيقة" if true_rul is not None else ""))
            else:
                self.kpi["false_alarms"] += 1
                msg += " — (إيقاف احترازي: لم يكن العطل وشيكاً)"
        self._event("shutdown", u, msg,
                    {"p_fail": p, "rul_pred": rul, "true_rul": true_rul, "reason": reason, "trace": trace,
                     "mode": u.likely_mode}, notify=True)
        u.clear_monitoring()
        self._start_standby(st, u)
        return True

    def start_pump(self, pid: str):
        u = self.units.get(pid)
        if not u or u.state not in ("standby", "stopped"):
            return False
        u.state = "running"
        u.clear_monitoring()
        u.ramp = 0
        if self.command_hook:
            self.command_hook(u.station_id, u.id, "start")
        self._event("info", u, f"تشغيل {u.id} يدوياً")
        return True

    def repair_pump(self, pid: str):
        u = self.units.get(pid)
        if not u or u.state not in ("maintenance", "failed"):
            return False
        self._repair(u)
        return True

    def inject(self, pid: str, mode: str, deg_ticks: int = 200):
        u = self.units.get(pid)
        if not u or not u.sim or mode not in MODES or u.state != "running":
            return False
        u.sim.inject_fault(mode, deg_ticks)
        self._event("info", u, f"[عرض] حُقن عطل «{MODE_AR[mode]}» في {u.id} للاختبار")
        return True

    # ------------------------------------------------------------------ مساعدات
    def _trace(self, u: PumpUnit) -> dict:
        d = {s: list(u.hist[s]) for s in SENSORS}
        d["p"] = list(u.p_hist)
        return d

    def _explain(self, u: PumpUnit) -> str:
        if len(u.window) < 5:
            return ""
        last = np.mean(list(u.window)[-5:], axis=0)
        devs = []
        for i, s in enumerate(SENSORS):
            z = (last[i] - BASE[s]) / Z_SCALE[s]
            if abs(z) >= 3:
                devs.append((abs(z), s, last[i]))
        devs.sort(reverse=True)
        parts = [f"{LABELS_AR[s]} {v:.1f} {UNITS[s]} (الطبيعي {BASE[s]:.1f})" for _, s, v in devs[:3]]
        return ("الانحرافات: " + "، ".join(parts)) if parts else ""

    def _station_metrics(self, st: Station):
        flow = sum(u.eff_flow for u in st.units)
        st.flow = flow
        st.service = min(100.0, 100.0 * flow / st.demand) if st.demand else 100.0
        # كشف التسرب: مقارنة تدفق المحطة بالتدفق عند نقطة المراقبة في الشبكة
        st.leak_true += float(np.clip(st.leak_target - st.leak_true, -0.002, 0.002))
        st.down_flow = flow * (1 - st.leak_true) + self.rng.gauss(0, 4.0)
        st.down_pressure = 3.9 * (1 - 0.5 * st.leak_true) + self.rng.gauss(0, 0.03) \
            if flow > 100 else self.rng.gauss(0.1, 0.02)
        if flow > 100:
            imb = (flow - st.down_flow) / flow
            st.imb_ema = 0.8 * st.imb_ema + 0.2 * imb
            if st.imb_ema > 0.035:
                st.leak_count += 1
                st.leak_clear = 0
            else:
                st.leak_count = 0
                st.leak_clear += 1
            st.leak_loss = max(0.0, st.imb_ema * flow)
            if not st.leak_alarm and st.leak_count >= 6:
                st.leak_alarm = True
                self.kpi["leaks_detected"] += 1
                self._event("leak", None,
                            f"اشتباه تسرب في خط {st.name}: فاقد ≈ {st.leak_loss:.0f} م³/ساعة "
                            f"({st.imb_ema:.1%} من التدفق) مع هبوط الضغط إلى {st.down_pressure:.2f} بار",
                            notify=True, station=st.id)
            if st.leak_alarm and st.leak_clear >= 10:
                st.leak_alarm = False
                self._event("info", None, f"زال اشتباه التسرب في {st.name}", station=st.id)

    def set_leak(self, station_id: str, fraction: float):
        for st in self.stations:
            if st.id == station_id:
                st.leak_target = float(np.clip(fraction, 0.0, 0.4))
                if fraction > 0:
                    self._event("info", None, f"[عرض] حُقن تسرب بنسبة {fraction:.0%} في خط {st.name}",
                                station=st.id)
                return True
        return False

    # ------------------------------------------------------------------ لقطة الحالة
    def snapshot(self) -> dict:
        stations = []
        for st in self.stations:
            pumps = []
            for u in st.units:
                warming = u.state == "running" and len(u.window) < WINDOW
                pumps.append({
                    "id": u.id, "state": u.state, "state_ar": STATE_AR.get(u.state, u.state),
                    "level": u.level, "level_ar": LEVEL_AR[u.level],
                    "health": _r(u.health, 0), "p_fail": _r(u.p_fail, 3), "rul": _r(u.rul, 0),
                    "mode": u.likely_mode, "mode_ar": MODE_AR.get(u.likely_mode, ""),
                    "mode_conf": _r(u.mode_conf, 2), "explain": u.explain, "warming": warming,
                    "source": u.source, "repair_left": u.repair_left,
                    "calibrated": (u.raw_base is not None) if u.source == "mqtt" else True,
                    "reading": {s: _r(u.reading[s], 2) for s in SENSORS},
                    "hist": {s: list(u.hist[s]) for s in SENSORS},
                    "p_hist": list(u.p_hist),
                })
            stations.append({
                "id": st.id, "name": st.name, "demand": st.demand, "flow": _r(st.flow, 0),
                "service": _r(st.service, 0), "pumps": pumps,
                "leak": {"alarm": st.leak_alarm, "loss": _r(st.leak_loss, 0), "imbalance": _r(st.imb_ema * 100, 1),
                         "down_flow": _r(st.down_flow, 0), "down_pressure": _r(st.down_pressure, 2),
                         "injected": st.leak_target > 0},
            })
        k = dict(self.kpi)
        k["net_savings"] = k["avoided_cost"] - k["failure_cost"]
        k["mean_lead"] = _r(np.mean(self.lead_times), 0) if self.lead_times else None
        return {
            "t": self.t, "clock": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "auto_shutdown": self.auto_shutdown, "tick_seconds": self.tick_seconds,
            "stations": stations, "kpi": k, "events": list(self.events)[:40],
            "limits": {s: v for s, v in HARD_LIMITS.items()},
            "metrics": self.metrics,
            "assumptions": {
                "unplanned_cost": C.UNPLANNED_FAILURE_COST_SAR, "planned_cost": C.PLANNED_STOP_COST_SAR,
            },
        }
