"""
سياسة القرار — تجمع مخرجات النموذج مع حدود أمان صلبة.

المستويات:
  normal    طبيعي
  watch     مراقبة
  warning   تحذير (إشعار + جدولة صيانة)
  critical  حرج (إيقاف تلقائي قبل العطل)

لتجنب الإيقاف الخاطئ بسبب قراءة شاذة واحدة، لا يُتخذ أي قرار إلا بعد
تكرار الشرط لعدد متتالٍ من الخطوات (debounce).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from simulator.pump_sim import BASE

# عتبات النموذج
P_WATCH = 0.25
P_WARNING = 0.50
P_CRITICAL = 0.80
RUL_CRITICAL = 45        # خطوة (دقيقة) — إيقاف إذا العمر المتبقي المقدّر أقل من هذا
CONFIRM_TICKS = 3        # عدد الخطوات المتتالية لتأكيد القرار

# حدود الأمان الصلبة (لا تعتمد على الذكاء الاصطناعي إطلاقاً)
HARD_LIMITS = {
    "temp": 95.0,
    "vib": 11.0,
    "current": BASE["current"] * 1.35,
}


def hard_limit_hit(reading: dict) -> Optional[str]:
    for s, lim in HARD_LIMITS.items():
        if reading.get(s, 0) >= lim:
            return s
    return None


@dataclass
class Decider:
    """حالة القرار لمضخة واحدة."""
    counts: dict = field(default_factory=lambda: {"watch": 0, "warning": 0, "critical": 0, "hard": 0})

    def reset(self):
        for k in self.counts:
            self.counts[k] = 0

    def update(self, p_fail: float, rul: float, reading: dict):
        """يُرجع (level, reason) حيث reason ∈ {None,'ai','hard_limit'}."""
        c = self.counts
        crit_ai = (p_fail >= P_CRITICAL and rul <= RUL_CRITICAL) or rul <= 15
        c["critical"] = c["critical"] + 1 if crit_ai else 0
        c["warning"] = c["warning"] + 1 if p_fail >= P_WARNING else 0
        c["watch"] = c["watch"] + 1 if p_fail >= P_WATCH else 0
        c["hard"] = c["hard"] + 1 if hard_limit_hit(reading) else 0

        if c["hard"] >= 2:
            return "critical", "hard_limit"
        if c["critical"] >= CONFIRM_TICKS:
            return "critical", "ai"
        if c["warning"] >= CONFIRM_TICKS:
            return "warning", None
        if c["watch"] >= CONFIRM_TICKS:
            return "watch", None
        return "normal", None
