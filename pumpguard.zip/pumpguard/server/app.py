"""
خادم PumpGuard (FastAPI)

    uvicorn server.app:app --host 0.0.0.0 --port 8000

لوحة التحكم:  http://localhost:8000
"""
from __future__ import annotations

import asyncio
import contextlib
import json
from pathlib import Path

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel

from reports import report_pdf, summarizer
from server import config as C
from server import mqtt_bridge, notify
from server.engine import Engine

ROOT = Path(__file__).resolve().parent.parent
engine = Engine()
engine.notifier = lambda text, kind, pdf: notify.send(text, kind)
clients: set[WebSocket] = set()


async def sim_loop():
    while True:
        engine.tick()
        if clients:
            payload = json.dumps(engine.snapshot(), ensure_ascii=False)
            dead = []
            for ws in list(clients):
                try:
                    await ws.send_text(payload)
                except Exception:  # noqa: BLE001
                    dead.append(ws)
            for ws in dead:
                clients.discard(ws)
        await asyncio.sleep(engine.tick_seconds)


async def report_loop():
    if C.REPORT_INTERVAL_MIN <= 0:
        return
    while True:
        await asyncio.sleep(C.REPORT_INTERVAL_MIN * 60)
        await asyncio.to_thread(send_report_now)


def send_report_now() -> dict:
    state = engine.snapshot()
    text, src = summarizer.summarize(state)
    pdf = report_pdf.summary_report(state, text, src)
    used = notify.send("📊 تقرير PumpGuard الدوري\n" + text, "report", pdf, "pumpguard_report.pdf")
    engine._event("info", None, f"أُرسل التقرير الدوري عبر: {'، '.join(used)}")
    return {"channels": used, "summary": text}


@contextlib.asynccontextmanager
async def lifespan(app: FastAPI):
    mqtt_bridge.start(engine)
    tasks = [asyncio.create_task(sim_loop()), asyncio.create_task(report_loop())]
    yield
    for t in tasks:
        t.cancel()


app = FastAPI(title="PumpGuard", lifespan=lifespan)


@app.get("/")
async def index():
    return FileResponse(ROOT / "dashboard" / "index.html")


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    clients.add(ws)
    try:
        await ws.send_text(json.dumps(engine.snapshot(), ensure_ascii=False))
        while True:
            await ws.receive_text()
    except (WebSocketDisconnect, Exception):  # noqa: BLE001
        clients.discard(ws)


@app.get("/api/state")
async def state():
    return engine.snapshot()


@app.get("/api/channels")
async def channels():
    return {**notify.channels_status(), "mqtt": bool(C.MQTT_HOST), "mqtt_pumps": C.MQTT_PUMPS,
            "llm": bool(__import__("os").getenv("ANTHROPIC_API_KEY"))}


class Inject(BaseModel):
    pump_id: str
    mode: str = "bearing"
    deg_ticks: int = 200


@app.post("/api/inject")
async def inject(b: Inject):
    if not engine.inject(b.pump_id, b.mode, max(60, min(b.deg_ticks, 700))):
        raise HTTPException(400, "تعذّر حقن العطل (المضخة ليست قيد التشغيل أو ليست محاكاة)")
    return {"ok": True}


class Leak(BaseModel):
    station_id: str
    fraction: float = 0.12


@app.post("/api/leak")
async def leak(b: Leak):
    if not engine.set_leak(b.station_id, b.fraction):
        raise HTTPException(404, "محطة غير موجودة")
    return {"ok": True}


@app.post("/api/pump/{pid}/{action}")
async def pump_action(pid: str, action: str):
    fn = {"stop": engine.stop_pump, "start": engine.start_pump, "repair": engine.repair_pump,
          "calibrate": engine.calibrate}.get(action)
    if not fn or pid not in engine.units:
        raise HTTPException(404, "غير موجود")
    ok = fn(pid)
    if not ok:
        raise HTTPException(400, "الإجراء غير ممكن في الحالة الحالية")
    return {"ok": True}


class Toggle(BaseModel):
    enabled: bool


@app.post("/api/auto_shutdown")
async def auto_shutdown(b: Toggle):
    engine.auto_shutdown = b.enabled
    engine._event("info", None, "الإيقاف التلقائي " + ("مُفعّل" if b.enabled else "معطّل (وضع المقارنة بدون النظام)"))
    return {"ok": True}


class Speed(BaseModel):
    tick_seconds: float


@app.post("/api/speed")
async def speed(b: Speed):
    engine.tick_seconds = max(0.05, min(b.tick_seconds, 2.0))
    return {"ok": True}


@app.get("/api/report.pdf")
async def report_pdf_endpoint():
    state = engine.snapshot()
    text, src = await asyncio.to_thread(summarizer.summarize, state)
    pdf = await asyncio.to_thread(report_pdf.summary_report, state, text, src)
    return Response(pdf, media_type="application/pdf",
                    headers={"Content-Disposition": 'inline; filename="pumpguard_report.pdf"'})


@app.get("/api/report/incident/{eid}.pdf")
async def incident_pdf(eid: int):
    ev = next((e for e in engine.events if e["id"] == eid), None)
    if not ev:
        raise HTTPException(404, "حدث غير موجود")
    state = engine.snapshot()
    text = await asyncio.to_thread(lambda: summarizer._llm(
        f"حلّل هذه الحادثة وأعطِ توصيات: {ev['message']}", state))
    pdf = await asyncio.to_thread(report_pdf.incident_report, state, ev, text)
    return Response(pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="incident_{eid}.pdf"'})


@app.post("/api/report/send")
async def report_send():
    return await asyncio.to_thread(send_report_now)


class Ask(BaseModel):
    question: str


@app.post("/api/ask")
async def ask(b: Ask):
    text, src = await asyncio.to_thread(summarizer.answer, b.question, engine.snapshot())
    return {"answer": text, "source": src}
