"""
جسر MQTT بين ESP32 والخادم.

  ESP32 → الخادم :  pumpguard/<محطة>/<مضخة>/telemetry   {"temp":..,"vib":..,"current":..,"pressure":..,"flow":..}
  الخادم → ESP32 :  pumpguard/<محطة>/<مضخة>/command     {"action":"stop"|"start"}
"""
from __future__ import annotations

import json

from server import config as C


def start(engine):
    if not C.MQTT_HOST:
        print("[mqtt] غير مفعّل (MQTT_HOST فارغ) — كل المضخات محاكاة")
        return None
    import paho.mqtt.client as mqtt

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="pumpguard-server")
    if C.MQTT_USER:
        client.username_pw_set(C.MQTT_USER, C.MQTT_PASS)

    def on_connect(c, userdata, flags, rc, props=None):
        print(f"[mqtt] متصل بـ {C.MQTT_HOST}:{C.MQTT_PORT} rc={rc}")
        c.subscribe("pumpguard/+/+/telemetry")

    def on_message(c, userdata, msg):
        try:
            _, _station, pump, _ = msg.topic.split("/")
            engine.mqtt_ingest(pump, json.loads(msg.payload))
        except Exception as e:  # noqa: BLE001
            print(f"[mqtt] رسالة غير صالحة: {e}")

    def command(station: str, pump: str, action: str):
        u = engine.units.get(pump)
        if u and u.source == "mqtt":
            client.publish(f"pumpguard/{station}/{pump}/command", json.dumps({"action": action}), qos=1)
            print(f"[mqtt] أمر {action} → {pump}")

    client.on_connect, client.on_message = on_connect, on_message
    engine.command_hook = command
    client.connect_async(C.MQTT_HOST, C.MQTT_PORT, 30)
    client.loop_start()
    return client
