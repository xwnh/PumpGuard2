"""توليد تقارير PDF عربية (RTL) — تقرير حالة عام وتقرير حادثة."""
from __future__ import annotations

import io
from pathlib import Path
from typing import Optional

import arabic_reshaper
from bidi.algorithm import get_display
from reportlab.graphics.shapes import Drawing, PolyLine, Rect, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, KeepTogether

FONTS = Path(__file__).resolve().parent / "fonts"
pdfmetrics.registerFont(TTFont("AR", str(FONTS / "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("AR-B", str(FONTS / "DejaVuSans-Bold.ttf")))

_reshaper = arabic_reshaper.ArabicReshaper({"delete_harakat": True})
NAVY, TEAL, RED, AMBER, GREEN, GRAY = (colors.HexColor(c) for c in
                                       ("#0B2545", "#13A89E", "#D64545", "#E8A317", "#2E9E5B", "#667085"))
LEVEL_COLOR = {"normal": GREEN, "watch": TEAL, "warning": AMBER, "critical": RED}


def ar(text) -> str:
    return get_display(_reshaper.reshape(str(text)))


def _wrap(text: str, font: str, size: float, width: float):
    lines, cur = [], ""
    for w in str(text).split():
        trial = (cur + " " + w).strip()
        if pdfmetrics.stringWidth(ar(trial), font, size) <= width or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def P(text, size=10, bold=False, color=colors.black, width=17 * cm, align=TA_RIGHT) -> Paragraph:
    font = "AR-B" if bold else "AR"
    st = ParagraphStyle("p", fontName=font, fontSize=size, leading=size * 1.6, alignment=align, textColor=color)
    lines = _wrap(text, font, size, width)
    return Paragraph("<br/>".join(ar(l).replace("&", "&amp;").replace("<", "&lt;") for l in lines), st)


def cell(text, width, size=8, bold=False, color=colors.black):
    return P(text, size=size, bold=bold, color=color, width=width - 0.2 * cm)


def table(rows, widths, header_bg=NAVY, size=8):
    """rows: قائمة صفوف منطقية (العمود الأول = الأيمن). نعكسها ليظهر الأول على اليمين."""
    data = []
    for i, r in enumerate(rows):
        out = []
        for j, c in enumerate(r):
            if isinstance(c, Paragraph):
                out.append(c)
            else:
                out.append(cell(c, widths[j], size=size, bold=(i == 0), color=colors.white if i == 0 else colors.black))
        data.append(out[::-1])
    t = Table(data, colWidths=widths[::-1], repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), header_bg),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F3F6F9")]),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#D0D5DD")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return t


def chart(values, title, color=TEAL, w=8.3 * cm, h=3.2 * cm, ymin=None, ymax=None):
    d = Drawing(w, h)
    d.add(Rect(0, 0, w, h, strokeColor=colors.HexColor("#D0D5DD"), fillColor=colors.white, strokeWidth=0.5))
    d.add(String(w - 4, h - 11, ar(title), fontName="AR-B", fontSize=8, textAnchor="end", fillColor=NAVY))
    vals = [float(v) for v in values if v is not None]
    if len(vals) >= 2:
        lo = min(vals) if ymin is None else ymin
        hi = max(vals) if ymax is None else ymax
        if hi - lo < 1e-9:
            hi = lo + 1
        pts = []
        for i, v in enumerate(vals):
            x = 6 + (w - 12) * i / (len(vals) - 1)
            y = 6 + (h - 24) * (v - lo) / (hi - lo)
            pts += [x, y]
        d.add(PolyLine(pts, strokeColor=color, strokeWidth=1.2))
        d.add(String(8, h - 11, f"{vals[-1]:.1f}", fontName="AR-B", fontSize=8, fillColor=color))
    return d


def _header(story, title, subtitle):
    story.append(P(title, size=17, bold=True, color=NAVY))
    story.append(P(subtitle, size=9, color=GRAY))
    story.append(Spacer(1, 0.3 * cm))


def _doc(buf):
    return SimpleDocTemplate(buf, pagesize=A4, leftMargin=1.8 * cm, rightMargin=1.8 * cm,
                             topMargin=1.5 * cm, bottomMargin=1.5 * cm,
                             title="PumpGuard Report", author="PumpGuard")


def _footer_note(story, state):
    story.append(Spacer(1, 0.4 * cm))
    story.append(P("ملاحظة: بيانات هذا النظام الأولي مأخوذة من محاكاة (ما عدا المضخات المربوطة بحساسات حقيقية عبر ESP32). "
                   "التكاليف افتراضات قابلة للتعديل وليست أرقاماً فعلية للجهة المشغّلة.", size=7.5, color=GRAY))


def summary_report(state: dict, summary_text: str, summary_source: str) -> bytes:
    buf = io.BytesIO()
    story = []
    _header(story, "PumpGuard — تقرير حالة محطات الضخ", f"أُعدّ في {state['clock']}")

    story.append(P(f"الملخص التنفيذي ({summary_source})", size=11, bold=True, color=TEAL))
    story.append(P(summary_text, size=9.5))
    story.append(Spacer(1, 0.3 * cm))

    k = state["kpi"]
    story.append(P("المؤشرات الرئيسية", size=11, bold=True, color=TEAL))
    rows = [["المؤشر", "القيمة"],
            ["أعطال تم تفاديها بالإيقاف الاستباقي", k["avoided_failures"]],
            ["أعطال مفاجئة وقعت", k["unplanned_failures"]],
            ["إيقافات تلقائية (المجموع)", k["shutdowns"]],
            ["إيقافات احترازية غير لازمة", k["false_alarms"]],
            ["متوسط زمن الإنذار المبكر (دقيقة)", k["mean_lead"] if k.get("mean_lead") else "—"],
            ["التوفير المحقق (ريال)", f"{k['avoided_cost']:,.0f}"],
            ["خسائر أعطال مفاجئة (ريال)", f"{k['failure_cost']:,.0f}"],
            ["صافي الأثر المالي (ريال)", f"{k['net_savings']:,.0f}"],
            ["ساعات توقف تم تفاديها", f"{k['hours_saved']:,.0f}"],
            ["حالات اشتباه تسرب مكتشفة", k["leaks_detected"]]]
    story.append(table(rows, [9 * cm, 4 * cm]))

    for st in state["stations"]:
        story.append(Spacer(1, 0.4 * cm))
        leak = st["leak"]
        story.append(P(f"{st['name']} — استمرارية الخدمة {st['service']:.0f}% — التدفق {st['flow']:.0f} م³/س"
                       + (f" — اشتباه تسرب (فاقد ≈ {leak['loss']:.0f} م³/س)" if leak["alarm"] else ""),
                       size=10, bold=True, color=NAVY))
        rows = [["المضخة", "الحالة", "المستوى", "الصحة%", "احتمال العطل", "المتبقي (د)", "حرارة", "اهتزاز", "تيار", "ضغط", "تدفق"]]
        for p in st["pumps"]:
            r = p["reading"]
            rows.append([p["id"], p["state_ar"],
                         P(p["level_ar"], 8, True, LEVEL_COLOR[p["level"]], width=1.5 * cm) if p["state"] == "running" else "—",
                         f"{p['health']:.0f}", f"{p['p_fail']:.0%}", f"{p['rul']:.0f}",
                         f"{r['temp']:.0f}", f"{r['vib']:.1f}", f"{r['current']:.0f}", f"{r['pressure']:.1f}", f"{r['flow']:.0f}"])
        story.append(table(rows, [1.4 * cm, 1.6 * cm, 1.5 * cm, 1.3 * cm, 1.8 * cm, 1.7 * cm, 1.2 * cm, 1.2 * cm, 1.2 * cm, 1.2 * cm, 1.4 * cm]))

    story.append(Spacer(1, 0.5 * cm))
    story.append(P("آخر الأحداث", size=11, bold=True, color=TEAL))
    rows = [["الوقت", "المضخة", "الحدث"]]
    for e in state["events"][:14]:
        rows.append([e["ts"], e["pump"] or e["station"] or "—", e["message"]])
    story.append(table(rows, [1.8 * cm, 1.6 * cm, 13.6 * cm]))

    m = state.get("metrics") or {}
    if m:
        fc, po = m["failure_classifier"], m["policy"]
        story.append(Spacer(1, 0.5 * cm))
        story.append(P("أداء نموذج التنبؤ (اختبار على مضخات محاكاة جديدة)", size=11, bold=True, color=TEAL))
        story.append(P(
            f"اكتشاف {po['detected_before_failure']} من {po['failures_tested']} عطلاً قبل وقوعه "
            f"({po['detection_rate']:.0%}) بمتوسط إنذار {po['mean_lead_minutes']:.0f} دقيقة، "
            f"و{po['false_shutdowns']} إيقاف خاطئ خلال {po['healthy_hours']:.0f} ساعة تشغيل لمضخات سليمة. "
            f"AUC = {fc['auc']:.3f}، الدقة {fc['precision']:.0%}، الاستدعاء {fc['recall']:.0%}.", size=9))
    _footer_note(story, state)
    _doc(buf).build(story)
    return buf.getvalue()


def incident_report(state: dict, event: dict, summary_text: Optional[str] = None) -> bytes:
    buf = io.BytesIO()
    story = []
    kinds = {"shutdown": "إيقاف تلقائي", "failure": "عطل مفاجئ", "warning": "تحذير مبكر", "critical": "حالة حرجة",
             "leak": "اشتباه تسرب", "failover": "تحويل للاحتياطي"}
    _header(story, f"تقرير حادثة — {kinds.get(event['kind'], event['kind'])}",
            f"المضخة: {event.get('pump') or '—'}   |   المحطة: {event.get('station') or '—'}   |   الوقت: {event['ts']}   |   رقم الحدث: {event['id']}")
    story.append(P("وصف الحدث", size=11, bold=True, color=TEAL))
    story.append(P(event["message"], size=10))
    d = event.get("data") or {}
    rows = [["البند", "القيمة"]]
    if "p_fail" in d:
        rows.append(["احتمال العطل المقدّر", f"{d['p_fail']:.0%}"])
    if d.get("rul_pred") is not None and "rul_pred" in d:
        rows.append(["العمر المتبقي المقدّر (دقيقة)", f"{d['rul_pred']:.0f}"])
    if d.get("true_rul") is not None:
        rows.append(["الوقت الحقيقي حتى العطل لو لم نتدخل (محاكاة)", f"{d['true_rul']:.0f} دقيقة"])
    if d.get("reason"):
        rows.append(["سبب الإيقاف", "حد أمان صلب" if d["reason"] == "hard_limit" else "تنبؤ الذكاء الاصطناعي"])
    if d.get("mode"):
        from simulator.pump_sim import MODE_AR
        rows.append(["نوع العطل المرجّح", MODE_AR.get(d["mode"], d["mode"])])
    if len(rows) > 1:
        story.append(Spacer(1, 0.2 * cm))
        story.append(table(rows, [9 * cm, 6 * cm]))

    tr = d.get("trace")
    if tr:
        story.append(Spacer(1, 0.4 * cm))
        story.append(P("قراءات الحساسات قبل الحدث (آخر 90 دقيقة)", size=11, bold=True, color=TEAL))
        grid = [[chart(tr["vib"], "الاهتزاز (مم/ث)", RED), chart(tr["temp"], "الحرارة (°م)", AMBER)],
                [chart(tr["current"], "التيار (أمبير)", NAVY), chart(tr["flow"], "التدفق (م³/س)", TEAL)],
                [chart(tr["pressure"], "الضغط (بار)", GREEN), chart(tr.get("p", []), "احتمال العطل", RED, ymin=0, ymax=1)]]
        t = Table(grid)
        t.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER"), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
        story.append(KeepTogether(t))
    if summary_text:
        story.append(Spacer(1, 0.3 * cm))
        story.append(P("تحليل وتوصيات", size=11, bold=True, color=TEAL))
        story.append(P(summary_text, size=9.5))
    _footer_note(story, state)
    _doc(buf).build(story)
    return buf.getvalue()
