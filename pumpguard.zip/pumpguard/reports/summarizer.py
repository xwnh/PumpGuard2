"""
ملخصات الذكاء الاصطناعي: Claude إن توفّر ANTHROPIC_API_KEY، وإلا ملخص آلي بقوالب عربية.
"""
from __future__ import annotations

import json
import os
from typing import Optional, Tuple

from server import config as C

SYSTEM = (
    "أنت مهندس صيانة تنبؤية خبير تكتب لمدير محطات ضخ مياه. اكتب بالعربية الفصحى المبسطة، بإيجاز ودقة، "
    "وبالاعتماد حصراً على البيانات المعطاة دون اختلاق أرقام. اذكر: الوضع العام، المضخات المقلقة وسببها المرجّح، "
    "الإجراءات المتخذة والأثر المالي، وتوصية واحدة إلى ثلاث للمشغّل. لا تستخدم عناوين markdown."
)


def context(state: dict) -> dict:
    pumps = []
    for st in state["stations"]:
        for p in st["pumps"]:
            pumps.append({
                "المحطة": st["name"], "المضخة": p["id"], "الحالة": p["state_ar"], "المستوى": p["level_ar"],
                "الصحة%": p["health"], "احتمال_العطل": p["p_fail"], "العمر_المتبقي_دقيقة": p["rul"],
                "العطل_المرجح": p["mode_ar"], "القراءات": p["reading"],
            })
    return {
        "الوقت": state["clock"],
        "المضخات": pumps,
        "المحطات": [{"الاسم": s["name"], "استمرارية_الخدمة%": s["service"], "تسرب": s["leak"]} for s in state["stations"]],
        "المؤشرات": state["kpi"],
        "آخر_الأحداث": [e["message"] for e in state["events"][:8]],
    }


def template_summary(state: dict) -> str:
    k = state["kpi"]
    allp = [(st["name"], p) for st in state["stations"] for p in st["pumps"]]
    running = [p for _, p in allp if p["state"] == "running"]
    bad = [(n, p) for n, p in allp if p["level"] in ("warning", "critical") and p["state"] == "running"]
    maint = [p["id"] for _, p in allp if p["state"] in ("maintenance", "failed")]
    out = [f"تعمل حالياً {len(running)} مضخات من أصل {len(allp)} تحت مراقبة الذكاء الاصطناعي."
           if 3 <= len(running) <= 10 else
           f"تعمل حالياً {len(running)} من أصل {len(allp)} مضخة تحت مراقبة الذكاء الاصطناعي."]
    if bad:
        parts = [f"{p['id']} ({p['level_ar']}، احتمال العطل {p['p_fail']:.0%}، العمر المتبقي ≈ {p['rul']:.0f} دقيقة"
                 + (f"، المرجّح: {p['mode_ar']}" if p["mode_ar"] else "") + ")" for _, p in bad]
        out.append("مضخات تستدعي الانتباه: " + "؛ ".join(parts) + ".")
    else:
        out.append("لا توجد مضخات في مستوى تحذير أو حرج حالياً.")
    if maint:
        out.append("قيد الصيانة/العطل: " + "، ".join(maint) + ".")
    out.append(
        f"أوقف النظام {k['shutdowns']} مضخة، منها {k['avoided_failures']} قبل عطل مؤكد، "
        f"بتوفير تقديري {k['avoided_cost']:,.0f} ريال"
        + (f"، وبمتوسط إنذار مبكر ≈ {k['mean_lead']:.0f} دقيقة" if k.get("mean_lead") else "") + "."
    )
    if k["unplanned_failures"]:
        out.append(f"وقعت {k['unplanned_failures']} أعطال مفاجئة بتكلفة {k['failure_cost']:,.0f} ريال.")
    leaks = [s for s in state["stations"] if s["leak"]["alarm"]]
    if leaks:
        out.append("تنبيه تسرب: " + "، ".join(f"{s['name']} (فاقد ≈ {s['leak']['loss']:.0f} م³/س)" for s in leaks) + ".")
    recs = []
    if bad:
        recs.append("جدولة صيانة المضخات المحذَّر منها خلال أقرب نافذة تشغيل")
    if leaks:
        recs.append("إرسال فريق ميداني لفحص الخط المشتبه بتسربه")
    if not recs:
        recs.append("الاستمرار في المراقبة الدورية")
    out.append("التوصيات: " + "؛ ".join(recs) + ".")
    return " ".join(out)


def _llm(prompt: str, state: dict) -> Optional[str]:
    if not os.getenv("ANTHROPIC_API_KEY"):
        return None
    try:
        import anthropic

        client = anthropic.Anthropic(timeout=25.0)
        msg = client.messages.create(
            model=C.LLM_MODEL, max_tokens=700, system=SYSTEM,
            messages=[{"role": "user", "content": json.dumps(context(state), ensure_ascii=False) + "\n\n" + prompt}],
        )
        return "".join(b.text for b in msg.content if getattr(b, "type", "") == "text").strip() or None
    except Exception as e:  # noqa: BLE001
        print(f"[llm] تعذّر استدعاء النموذج: {e}")
        return None


def summarize(state: dict) -> Tuple[str, str]:
    t = _llm("اكتب ملخصاً تنفيذياً من 4 إلى 6 جمل لحالة المحطات الآن.", state)
    return (t, "Claude") if t else (template_summary(state), "آلي")


def answer(question: str, state: dict) -> Tuple[str, str]:
    t = _llm(f"سؤال المشغّل: {question}\nأجب بإيجاز اعتماداً على البيانات فقط.", state)
    if t:
        return t, "Claude"
    q = question.replace("؟", " ")
    for st in state["stations"]:
        for p in st["pumps"]:
            if p["id"].lower() in q.lower():
                return (f"{p['id']}: الحالة {p['state_ar']}، المستوى {p['level_ar']}، الصحة {p['health']}%، "
                        f"احتمال العطل {p['p_fail']:.0%}، العمر المتبقي ≈ {p['rul']:.0f} دقيقة. "
                        + (p["explain"] or "")), "آلي"
    return template_summary(state), "آلي"
