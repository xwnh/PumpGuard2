"""
محاكي المضخات — PumpGuard
=========================
يولّد قراءات حساسات واقعية لمضخة طرد مركزي (حرارة، اهتزاز، تيار، ضغط، تدفق)
مع أربعة أنماط أعطال تتدهور تدريجياً حتى الفشل:

  bearing     تآكل المحامل       ← اهتزاز + حرارة
  cavitation  التكهف (Cavitation) ← هبوط ضغط الشفط + اهتزاز عشوائي + هبوط تدفق
  overheat    ارتفاع حرارة المحرك ← حرارة + تيار
  clog        انسداد المروحة      ← هبوط تدفق + ارتفاع تيار وضغط التصريف

العناصر الواقعية المضمَّنة (حتى لا يكون النموذج "يغش" على بيانات مثالية):
  - ضجيج حساسات + قراءات شاذة عشوائية (spikes)
  - تغيّر الحِمل الدوري (طلب المياه) الذي يحرّك القراءات حتى والمضخة سليمة
  - قصور حراري (الحرارة لا تقفز فوراً)
  - تسارع التدهور (أُسّي) مع عشوائية في المعدل

ملاحظة أمانة علمية: هذه بيانات محاكاة مبنية على بصمات الأعطال المعروفة في أدبيات
الصيانة التنبؤية، وليست بيانات تشغيل حقيقية.
"""
from __future__ import annotations

import math
import random
from typing import Dict, Optional

SENSORS = ["temp", "vib", "current", "pressure", "flow"]

# القيم الطبيعية لمضخة سليمة
BASE: Dict[str, float] = {
    "temp": 55.0,      # °م   حرارة غلاف المحرك/المحمل
    "vib": 2.0,        # مم/ث اهتزاز (RMS سرعة)
    "current": 42.0,   # أمبير
    "pressure": 4.5,   # بار  ضغط التصريف
    "flow": 320.0,     # م³/ساعة
}
NOISE: Dict[str, float] = {"temp": 0.6, "vib": 0.12, "current": 0.5, "pressure": 0.06, "flow": 3.5}
UNITS: Dict[str, str] = {"temp": "°م", "vib": "مم/ث", "current": "أمبير", "pressure": "بار", "flow": "م³/س"}
LABELS_AR: Dict[str, str] = {
    "temp": "الحرارة", "vib": "الاهتزاز", "current": "التيار", "pressure": "الضغط", "flow": "التدفق",
}

MODES = ["bearing", "cavitation", "overheat", "clog"]
MODE_AR: Dict[str, str] = {
    "bearing": "تآكل المحامل",
    "cavitation": "التكهف (Cavitation)",
    "overheat": "ارتفاع حرارة المحرك",
    "clog": "انسداد المروحة",
    "none": "لا يوجد",
}

# (حساس، معامل التأثير، أُس الضرر)
EFFECTS = {
    "bearing": [("vib", 9.0, 1.5), ("temp", 22.0, 1.2), ("current", 3.5, 1.0)],
    "cavitation": [("pressure", -1.7, 1.2), ("vib", 5.5, 1.3), ("flow", -70.0, 1.2)],
    "overheat": [("temp", 38.0, 1.3), ("current", 9.0, 1.1)],
    "clog": [("flow", -160.0, 1.1), ("current", 7.0, 1.0), ("pressure", 1.0, 1.0)],
}

AMBIENT = 30.0
LOAD_PERIOD = 240  # عدد الخطوات في دورة الطلب الواحدة


class Pump:
    """مضخة واحدة. كل step() = دقيقة واحدة من زمن المحطة."""

    def __init__(
        self,
        pid: str,
        rng: Optional[random.Random] = None,
        mode: Optional[str] = None,
        onset: Optional[int] = None,
        deg_ticks: Optional[int] = None,
        healthy: bool = False,
        state: str = "running",
    ):
        self.id = pid
        self.rng = rng or random.Random()
        self.reset(mode, onset, deg_ticks, healthy, state)

    # ------------------------------------------------------------------ حالة
    def reset(self, mode=None, onset=None, deg_ticks=None, healthy=False, state="running"):
        r = self.rng
        self.t = 0
        self.damage = 0.0
        self.mode = mode or r.choice(MODES)
        self.healthy_only = healthy
        self.onset = onset if onset is not None else r.randint(150, 600)
        self.deg_ticks = deg_ticks if deg_ticks is not None else r.randint(180, 700)
        # dd/dt = b(1+6d)  ⇒ الزمن من 0 إلى 1 = ln(7)/(6b)
        self.b = math.log(7.0) / (6.0 * self.deg_ticks)
        self.state = state  # running | standby | stopped | failed | maintenance
        self.phase = r.uniform(0, 2 * math.pi)
        self.temp = BASE["temp"] if state == "running" else AMBIENT
        self.failed_at: Optional[int] = None

    def inject_fault(self, mode: str, deg_ticks: int = 200):
        """يبدأ تدهوراً فورياً (للعرض الحي أمام اللجنة)."""
        self.mode = mode
        self.healthy_only = False
        self.damage = max(self.damage, 0.0)
        self.onset = self.t
        self.deg_ticks = deg_ticks
        self.b = math.log(7.0) / (6.0 * deg_ticks)

    def true_rul(self) -> float:
        """العمر المتبقي الحقيقي (معلوم فقط في المحاكاة) بالخطوات."""
        if self.healthy_only:
            return float("inf")
        if self.damage >= 1.0:
            return 0.0
        d = self.damage
        wait = max(0, self.onset - self.t)
        return wait + math.log(7.0 / (1.0 + 6.0 * d)) / (6.0 * self.b)

    # ------------------------------------------------------------------ خطوة
    def step(self) -> Dict[str, float]:
        self.t += 1
        r = self.rng
        running = self.state in ("running", "failed")

        if self.state == "running" and not self.healthy_only and self.t > self.onset and self.damage < 1.0:
            self.damage = min(1.0, self.damage + self.b * (1 + 6 * self.damage) * r.uniform(0.7, 1.3))
            if self.damage >= 1.0:
                self.state = "failed"
                self.failed_at = self.t

        d = self.damage
        load = 1 + 0.06 * math.sin(2 * math.pi * self.t / LOAD_PERIOD + self.phase)

        if running:
            v = dict(BASE)
            v["flow"] *= load
            v["current"] *= 1 + 0.8 * (load - 1)
            v["pressure"] *= 1 - 0.3 * (load - 1)
            v["vib"] *= 1 + 0.5 * (load - 1)
            v["temp"] += 4.0 * (load - 1)
            for s, gain, exp in EFFECTS[self.mode]:
                v[s] += gain * (d ** exp)
            if self.state == "failed":
                v["flow"] *= 0.15
                v["vib"] += 3.0
                v["current"] += 6.0
            # قصور حراري
            self.temp += 0.25 * (v["temp"] - self.temp)
            v["temp"] = self.temp
        else:
            v = {"flow": 0.0, "current": 0.3, "vib": 0.15, "pressure": 0.1, "temp": 0.0}
            self.temp += 0.08 * (AMBIENT - self.temp)
            v["temp"] = self.temp

        out = {}
        for s in SENSORS:
            sigma = NOISE[s]
            if s == "vib" and self.mode == "cavitation" and running:
                sigma *= 1 + 2.5 * d
            val = v[s] + r.gauss(0, sigma)
            out[s] = val
        # قراءة شاذة عشوائية (1%) لاختبار متانة النظام
        if running and r.random() < 0.01:
            s = r.choice(SENSORS)
            out[s] += r.choice([-1, 1]) * 5 * NOISE[s]
        for s in ("flow", "current", "vib", "pressure"):
            out[s] = max(0.0, out[s])
        return out
