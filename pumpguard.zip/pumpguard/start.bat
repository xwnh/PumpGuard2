@echo off
chcp 65001 >nul
cd /d %~dp0
if not exist .venv ( python -m venv .venv )
call .venv\Scripts\activate
pip install -q -r requirements.txt
if not exist models\fail_clf.joblib ( python -m ml.train )
echo.
echo ===== افتح المتصفح على:  http://localhost:8000 =====
python -m uvicorn server.app:app --host 0.0.0.0 --port 8000
