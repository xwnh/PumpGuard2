"""استخراج الخصائص من نافذة القراءات — يُستخدم نفسه في التدريب وفي التشغيل الحي."""
from __future__ import annotations

import numpy as np

from simulator.pump_sim import BASE, SENSORS

WINDOW = 30
_BASE = np.array([BASE[s] for s in SENSORS], dtype=float)


def window_features(win: np.ndarray) -> np.ndarray:
    """win: مصفوفة (n, 5) بترتيب SENSORS، n >= 10. تُرجع متجه خصائص (30)."""
    x = np.asarray(win, dtype=float)
    n = len(x)
    t = np.arange(n) - (n - 1) / 2.0
    slope = (t[:, None] * (x - x.mean(0))).sum(0) / (t ** 2).sum()
    last = x[-5:].mean(0)
    mean = x.mean(0)
    std = x.std(0)
    first = x[: max(5, n // 3)].mean(0)
    delta = last - first
    rel = last / _BASE
    return np.concatenate([last, mean, std, slope, delta, rel])


FEATURE_NAMES = [f"{kind}_{s}" for kind in ("last", "mean", "std", "slope", "delta", "rel") for s in SENSORS]
