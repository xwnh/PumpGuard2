"""
تدريب نماذج PumpGuard وتقييمها.

    python -m ml.train

المخرجات (مجلد models/):
  fail_clf.joblib   احتمال العطل خلال الأفق H
  rul_reg.joblib    العمر المتبقي المقدّر (بالدقائق)
  mode_clf.joblib   نوع العطل المتوقع
  metrics.json      مقاييس الأداء (تُعرض في لوحة التحكم والتقرير)

التقييم على مضخات جديدة كلياً (seeds مختلفة) وليس على صفوف عشوائية من نفس التشغيلات،
ثم تُشغَّل سياسة القرار الحقيقية (server/decision.py) على كل تشغيل لقياس:
  - نسبة الأعطال التي تم اكتشافها وإيقافها قبل وقوعها
  - متوسط زمن الإنذار المبكر
  - عدد الإيقافات الخاطئة لكل 1000 ساعة تشغيل لمضخات سليمة
"""
from __future__ import annotations

import json
import random
import time
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.metrics import roc_auc_score, precision_score, recall_score, f1_score, accuracy_score

from ml.features import WINDOW, window_features
from server.decision import Decider
from simulator.pump_sim import MODES, SENSORS, Pump

MODELS = Path(__file__).resolve().parent.parent / "models"
HORIZON = 90      # "عطل قريب" = خلال 90 دقيقة
RUL_CAP = 400
MODE_NEAR = 250   # نوع العطل يُعرَّف فقط عندما يكون العطل ضمن 250 دقيقة
CLASSES = ["none"] + MODES


def run_pump(seed: int, mode: str | None, healthy: bool, max_ticks: int = 1600):
    """يشغّل مضخة حتى العطل (أو max_ticks للسليمة). يُرجع (قراءات[n,5], failure_tick|None, mode)."""
    rng = random.Random(seed)
    p = Pump(f"s{seed}", rng=rng, mode=mode, healthy=healthy)
    rows = []
    fail_t = None
    for _ in range(max_ticks):
        r = p.step()
        rows.append([r[s] for s in SENSORS])
        if p.state == "failed":
            fail_t = p.t
            break
    return np.array(rows), fail_t, p.mode


def build_dataset(seeds_fail, seeds_healthy, stride=2):
    X, y_fail, y_rul, y_mode = [], [], [], []
    for i, sd in enumerate(seeds_fail):
        mode = MODES[i % len(MODES)]
        rows, fail_t, mode = run_pump(sd, mode, False)
        if fail_t is None:
            continue
        for t in range(WINDOW, len(rows), stride):
            rul = fail_t - (t + 1)
            X.append(window_features(rows[t - WINDOW + 1 : t + 1]))
            y_fail.append(int(rul <= HORIZON))
            y_rul.append(np.log1p(min(rul, RUL_CAP)))
            y_mode.append(CLASSES.index(mode) if rul <= MODE_NEAR else 0)
    for sd in seeds_healthy:
        rows, _, _ = run_pump(sd, None, True, max_ticks=900)
        for t in range(WINDOW, len(rows), stride * 2):
            X.append(window_features(rows[t - WINDOW + 1 : t + 1]))
            y_fail.append(0)
            y_rul.append(np.log1p(RUL_CAP))
            y_mode.append(0)
    return np.array(X), np.array(y_fail), np.array(y_rul), np.array(y_mode)


def predict_all(models, rows):
    """تنبؤ لكل خطوة t في تشغيل كامل (نفس ما يحدث في التشغيل الحي)."""
    fail_clf, rul_reg, _ = models
    idx = list(range(WINDOW, len(rows)))
    F = np.array([window_features(rows[t - WINDOW + 1 : t + 1]) for t in idx])
    p = fail_clf.predict_proba(F)[:, 1]
    rul = np.expm1(rul_reg.predict(F))
    return idx, p, rul


def evaluate_policy(models, n_fail=60, n_healthy=40, seed0=900_000):
    """يشغّل سياسة القرار الفعلية على مضخات اختبار جديدة."""
    detected, leads, early_waste, missed = 0, [], [], 0
    for i in range(n_fail):
        rows, fail_t, _ = run_pump(seed0 + i, MODES[i % 4], False)
        if fail_t is None:
            continue
        idx, p, rul = predict_all(models, rows)
        dec = Decider()
        stop_t = None
        for t, pp, rr in zip(idx, p, rul):
            lvl, _ = dec.update(pp, rr, dict(zip(SENSORS, rows[t])))
            if lvl == "critical":
                stop_t = t
                break
        if stop_t is not None and stop_t < fail_t:
            detected += 1
            leads.append(fail_t - stop_t)
        else:
            missed += 1
    false_stops, healthy_ticks = 0, 0
    for i in range(n_healthy):
        rows, _, _ = run_pump(seed0 + 5000 + i, None, True, max_ticks=1500)
        idx, p, rul = predict_all(models, rows)
        dec = Decider()
        for t, pp, rr in zip(idx, p, rul):
            lvl, _ = dec.update(pp, rr, dict(zip(SENSORS, rows[t])))
            healthy_ticks += 1
            if lvl == "critical":
                false_stops += 1
                break
    n = detected + missed
    return {
        "failures_tested": n,
        "detected_before_failure": detected,
        "detection_rate": round(detected / max(n, 1), 4),
        "mean_lead_minutes": round(float(np.mean(leads)), 1) if leads else 0,
        "min_lead_minutes": int(np.min(leads)) if leads else 0,
        "healthy_pumps_tested": n_healthy,
        "healthy_hours": round(healthy_ticks / 60, 1),
        "false_shutdowns": false_stops,
        "false_shutdowns_per_1000h": round(false_stops / max(healthy_ticks / 60, 1e-9) * 1000, 2),
    }


def main():
    t0 = time.time()
    MODELS.mkdir(exist_ok=True)
    print("توليد بيانات التدريب ...")
    Xtr, yf, yr, ym = build_dataset(range(0, 320), range(10_000, 10_070))
    print(f"  عينات التدريب: {len(Xtr):,}   نسبة 'عطل قريب': {yf.mean():.2%}")

    print("تدريب نموذج احتمال العطل ...")
    fail_clf = HistGradientBoostingClassifier(max_iter=250, learning_rate=0.08, random_state=0).fit(Xtr, yf)
    print("تدريب نموذج العمر المتبقي ...")
    rul_reg = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.08, random_state=0).fit(Xtr, yr)
    print("تدريب نموذج نوع العطل ...")
    mode_clf = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.08, random_state=0).fit(Xtr, ym)

    print("بيانات اختبار (مضخات جديدة كلياً) ...")
    Xte, yf_te, yr_te, ym_te = build_dataset(range(500_000, 500_080), range(510_000, 510_025))
    pf = fail_clf.predict_proba(Xte)[:, 1]
    pred_f = (pf >= 0.5).astype(int)
    rul_true = np.expm1(yr_te)
    rul_pred = np.expm1(rul_reg.predict(Xte))
    near = rul_true <= 200
    ym_pred = mode_clf.predict(Xte)
    near_mode = ym_te != 0

    metrics = {
        "trained_on": {"samples": int(len(Xtr)), "failing_pumps": 320, "healthy_pumps": 70},
        "horizon_minutes": HORIZON,
        "failure_classifier": {
            "auc": round(float(roc_auc_score(yf_te, pf)), 4),
            "precision": round(float(precision_score(yf_te, pred_f)), 4),
            "recall": round(float(recall_score(yf_te, pred_f)), 4),
            "f1": round(float(f1_score(yf_te, pred_f)), 4),
        },
        "rul": {"mae_minutes_when_rul_le_200": round(float(np.mean(np.abs(rul_true[near] - rul_pred[near]))), 1)},
        "mode_classifier": {
            "accuracy_when_failure_near": round(float(accuracy_score(ym_te[near_mode], ym_pred[near_mode])), 4)
        },
    }
    print("تقييم سياسة القرار الكاملة ...")
    metrics["policy"] = evaluate_policy((fail_clf, rul_reg, mode_clf))
    metrics["note"] = "المقاييس على بيانات محاكاة لمضخات لم تُستخدم في التدريب، وليست بيانات تشغيل حقيقية."
    metrics["classes"] = CLASSES

    joblib.dump(fail_clf, MODELS / "fail_clf.joblib")
    joblib.dump(rul_reg, MODELS / "rul_reg.joblib")
    joblib.dump(mode_clf, MODELS / "mode_clf.joblib")
    (MODELS / "metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    print(f"تم في {time.time() - t0:.0f} ثانية")


if __name__ == "__main__":
    main()
